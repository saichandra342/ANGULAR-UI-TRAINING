let obj = require("./sports");

obj.f1();
obj.f2();

console.log(obj.name);
console.log(obj.address);
console.log(obj.add);
console.log(obj.age); // not accesible
