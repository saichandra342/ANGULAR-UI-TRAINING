import * as math from "module_1"
console.log("2π = " + math.sum(math.pi, math.pi))