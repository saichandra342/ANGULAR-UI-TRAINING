var sports = require('./sports.js');
sports.cricket();
sports.football();