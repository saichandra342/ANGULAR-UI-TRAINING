function cricket() {
  console.log("this is cricket function");
}
function football() {
  console.log("this is footbale function");
}

module.exports.cricket = cricket;
module.exports.football = football;
