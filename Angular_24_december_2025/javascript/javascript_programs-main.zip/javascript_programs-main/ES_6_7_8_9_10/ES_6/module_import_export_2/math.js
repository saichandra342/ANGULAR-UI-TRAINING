//default export
export default function add(a, b) {
  return a + b;
}

//named export
export function sub(a, b) {
  return a - b;
}

export let myName = "sanjay";
