var obj = require('./demo.js');
obj.f1();
console.log(obj.x);
console.log(obj.y);
console.log(obj.yy);
