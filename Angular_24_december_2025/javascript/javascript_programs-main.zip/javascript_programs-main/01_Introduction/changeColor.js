document.getElementById("one").style.color = "red";
