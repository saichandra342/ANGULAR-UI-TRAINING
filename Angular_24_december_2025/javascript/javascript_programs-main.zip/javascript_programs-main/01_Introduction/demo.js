var a = 10;
console.log(a);

// document.getElementById("one").style.color = "red";
