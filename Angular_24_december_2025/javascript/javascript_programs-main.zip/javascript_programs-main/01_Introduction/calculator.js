function add(a, b) {
  console.log(a + b);
}
add(2,3);

function sub(a, b) {
  console.log(a - b);
}
sub(10,2);
