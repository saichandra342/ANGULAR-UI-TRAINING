var x=5;				
document.write("x: "+x+"<br>");	
var y=6;		
document.write("Y: "+y);

var age=22;
if(age>18){
	document.getElementById("test").innerHTML = 
	"eligible";
}
else{
	document.getElementById("test").innerHTML = 
	"Not eligible";
}

