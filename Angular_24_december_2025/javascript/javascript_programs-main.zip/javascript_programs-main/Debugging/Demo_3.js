	function fun3()
	{
		alert("this is fun3")
	}
	function fun2()
	{
	   var p=10,q=20,r=30;
	   console.log(p);
	   fun3();
	   console.log(t);
	   console.log(r);
	}
	function fun1(){
	   var a=5,b=6,c=7,d=8;
	   console.log(a);
	   console.log(b);
	   fun2();
	   console.log(c);
	   console.log(d);
	   }
